from kyt import *
import logging
import requests
import time
import json
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackQueryHandler, CallbackContext

# Set up logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)
logger = logging.getLogger(__name__)

# Cloudflare API settings
CLOUDFLARE_API_KEY = 'd3e27af474728cd2c31ba76a433b1bc90cd51'
CLOUDFLARE_EMAIL = 'super.anggaaa@gmail.co.'
CLOUDFLARE_ZONE_ID = '7e26eb7e6246396f8b2afa423c0203d9'

# Telegram Bot Token
TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'

# File to store user data and uptime
DATA_FILE = 'bot_data.json'

# Initialize data
try:
    with open(DATA_FILE, 'r') as f:
        data = json.load(f)
    if 'start_time' not in data or data['start_time'] == 0:
        data['start_time'] = time.time()
        with open(DATA_FILE, 'w') as f:
            json.dump(data, f)
except (FileNotFoundError, json.JSONDecodeError):
    data = {
        'users': [],
        'start_time': time.time()
    }
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f)

def save_data():
    with open(DATA_FILE, 'w') as f:
        json.dump(data, f)

# Function to create DNS record
def create_dns_record(name, content, record_type='A'):
    url = f"https://api.cloudflare.com/client/v4/zones/{CLOUDFLARE_ZONE_ID}/dns_records"
    headers = {
        'X-Auth-Email': super.anggaaa@gmail.com,
        'X-Auth-Key': d3e27af474728cd2c31ba76a433b1bc90cd51,
        'Content-Type': 'application/json'
    }
    data = {
        'type': record_type,
        'name': name,
        'content': content,
        'ttl': 120,
        'proxied': False
    }
    response = requests.post(url, json=data, headers=headers)
    return response.json()

# Start command handler
def start(update: Update, _: CallbackContext) -> None:
    user_id = update.message.from_user.id
    if user_id not in data['users']:
        data['users'].append(user_id)
        save_data()

    uptime_seconds = time.time() - data['start_time']
    days, rem = divmod(uptime_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    uptime = f"{int(days)} hari, {int(hours)} jam, {int(minutes)} menit, {int(seconds)} detik"

    user_info = (
        f"USER INFO\n"
        f"Your ID: {user_id}\n"
        f"Username: @{update.message.from_user.username}\n"
        f"First Name: {update.message.from_user.first_name}\n"
        f"Last Name: {update.message.from_user.last_name}\n\n"
        f"Total Pengguna Bot: {len(data['users'])}\n"
        f"Bot Uptime: {uptime}\n\n"
        f"Note: Silahkan Klik /cancel Untuk Membatalkan Oprasi Pada Bot"
    )
    update.message.reply_text(user_info)
    menu(update, _)

# Menu command handler
def menu(update: Update, _: CallbackContext) -> None:
    keyboard = [
        [InlineKeyboardButton("angga.foundatiom", callback_data='angga.foundation')],
        [InlineKeyboardButton("caramelia.biz.id", callback_data='caramelia.biz.id')],
        [InlineKeyboardButton("satantech.cloud", callback_data='satantech.cloud')],
        [InlineKeyboardButton("supersaiya.cloud", callback_data='supersaiya.cloud')],
        [InlineKeyboardButton("tepllovpn.eu.org", callback_data='tepllovpn.eu.org')],
        [InlineKeyboardButton("vpnku.biz.id", callback_data='vpnku.biz.id')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    update.message.reply_text('Pilih subdomain:', reply_markup=reply_markup)

# Callback query handler
def button(update: Update, _: CallbackContext) -> None:
    query = update.callback_query
    query.answer()
    subdomain = query.data
    query.edit_message_text(text=f"Gunakan format /create {subdomain} content untuk membuat record baru.")

# Create command handler
def create(update: Update, _: CallbackContext) -> None:
    args = update.message.text.split()
    if len(args) != 3:
        update.message.reply_text('Format salah! Gunakan /create name content')
        return

    name, content = args[1], args[2]
    result = create_dns_record(name, content)
    if result['success']:
        update.message.reply_text(f"DNS record {name} created successfully!")
    else:
        update.message.reply_text(f"Failed to create DNS record: {result['errors']}")

def main() -> None:
    # Create the Updater and pass it your bot's token.
    updater = Updater(7032109934:AAFqUkwtMX0XBGSd5uTik8MAcsoU5nVyyf4)

    # Get the dispatcher to register handlers
    dispatcher = updater.dispatcher

    # Add handlers
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("menu", menu))
    dispatcher.add_handler(CallbackQueryHandler(button))
    dispatcher.add_handler(CommandHandler("create", create))

    # Start the Bot
    updater.start_polling()

    # Run the bot until you press Ctrl-C or the process receives SIGINT, SIGTERM or SIGABRT.
    updater.idle()

if __name__ == '__main__':
    main()
